CartMacro - Fabric project for Minecraft Java 1.21.11

This is the SOURCE PROJECT, not a precompiled .jar.

Target:
- Minecraft Java 1.21.11
- Fabric Loader
- Java 21
- Yarn mappings 1.21.11+build.6
- Fabric API 0.141.4+1.21.11

Build:
1. Install Java 21 and Gradle 9.2.1 or newer.
2. Open a terminal in this folder.
3. Run: gradle build
4. The mod jar will be in: build/libs/

Install:
Copy the built cartmacro-1.0.0.jar into the Minecraft instance's mods folder.
Fabric API must also be installed.

In game:
- Put placeable blocks in hotbar slot 3.
- Press G.
- The key can be changed in Options > Controls > Key Binds.

Important:
The code attempts one placement using the block hit position it calculates.
It is not guaranteed to place successfully in every position or on every server.
Test in a creative/single-player world first. Server rules may restrict macros.


CLOUD BUILD (no Termux required on your phone):
1. Create/sign in to a GitHub account.
2. On GitHub, create a new public or private repository named CartMacro.
3. Upload the contents of this project folder to the repository (including the hidden .github folder).
4. Open the repository's Actions tab.
5. Select "Build CartMacro" and press "Run workflow" if it has not started automatically.
6. When the run finishes successfully, open the run and download the artifact named
   cartmacro-fabric-1.21.11. The mod JAR is inside that downloaded artifact ZIP.
