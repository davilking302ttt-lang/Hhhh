package com.cartmacro;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class CartMacro implements ClientModInitializer {
    private static KeyBinding trigger;

    @Override
    public void onInitializeClient() {
        trigger = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.cartmacro.place",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_G,
                KeyBinding.Category.create(Identifier.of("cartmacro", "main"))
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (trigger.consumeClick()) {
                if (client.player == null || client.interactionManager == null) {
                    continue;
                }

                var player = client.player;
                int oldSlot = player.getInventory().selectedSlot;

                // Hotbar slot 3 (Java index 2).
                player.getInventory().selectedSlot = 2;

                // Jump, then attempt the placement at the block directly below.
                player.jump();

                BlockPos below = BlockPos.containing(
                    player.getX(),
                    player.getY() - 0.1,
                    player.getZ()
                );
                BlockPos support = below.down();

                BlockHitResult hit = new BlockHitResult(
                    Vec3d.atCenterOf(support).add(0.0, 0.5, 0.0),
                    Direction.UP,
                    support,
                    false
                );

                client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);

                // Restore the previously selected hotbar slot.
                player.getInventory().selectedSlot = oldSlot;
            }
        });
    }
}
